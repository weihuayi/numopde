function f=f(x)
  f=16*pi*pi*sin(4*pi*x);
   %f=exp(-x.^2).*(4-14*x.^2+4*x.^4);
end