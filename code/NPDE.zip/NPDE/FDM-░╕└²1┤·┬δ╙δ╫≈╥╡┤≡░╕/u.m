function u=u(x)
  u=sin(4*pi*x);
 %u=exp(-x.^2).*(1-x.^2);
end